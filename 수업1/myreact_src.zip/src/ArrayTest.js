
import React from "react";
class ArrayTest extends React.Component{
render(){
    const sample = ['a','b','c','d','e'];
    //sample.push('g');
    //sample.pop();
    //const resultsample = sample.splice(1, 2); //1번 인덱스부터 2개 삭제
    const resultsample = sample.filter(function( one ){   return one != 'a'  });
    return(<div> <h3>샘플= {sample}</h3> <h3>결과= {resultsample}</h3></div>);

}

}
//샘플= abcde
//결과= bcde  // 'a' 삭제 후 결과배열
export default ArrayTest;

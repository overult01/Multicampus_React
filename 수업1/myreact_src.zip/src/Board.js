
//test1
//전달은 ---  <Route path="/board/*" element={<Board seq="1" />}  />
//const Board = (props)=>{
//    console.log(props.seq)
//    return (<div><h2> {props.seq} 번 게시물입니다.</h2></div>);
//}

//test2
//<Route path="/board/:seq" element={<Board />}  />
//import { useParams } from "react-router-dom";

//const Board = ()=>{
//    const {seq, title } = useParams();
    //useParams(url 포함 파라미터 정보( :변수명 ) 제공) 리턴결과가 객체인데 객체 포함 변수 중 seq, title 변수만 가져와서 사용

//    return (<div><h2> {seq} 번 제목이 {title}인 게시물입니다.</h2></div>);
//}

//test3 - get http url? - query string 전달받기
import { useSearchParams } from "react-router-dom";
const Board = ()=>{
    const [searchParams] = useSearchParams(); 
    // useSearchParams(); 제공 정보 가운데 이름이 searchParams 변수만 가져온다
    //console.log(searchParams);
    const seq = searchParams.get("seq");
    const title = searchParams.get("title");
    const writer = searchParams.get("writer");

return (<div><h3>{seq} 번 {title} 제목의 글을 {writer} 가 작성하셨습니다.</h3></div>);
}
export default Board;
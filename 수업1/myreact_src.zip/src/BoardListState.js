import React from "react";
class BoardHeading extends React.Component{
    render(){
        return(<thead><tr><th>번호</th><th>제목</th><th>작성자</th></tr></thead>);
    }

}

class BoardRow extends React.Component{
    //BoardList 에서 전달받은 board 변수에 존재하는 게시물만큼 테이블 행 구성
    //constructor(props){
    //    super(props);
    // }

    render(){
        const tr_tag = this.props.board.map(function(one) {
            return (<tr key={one.seq}><td>{one.seq}</td><td>{one.title}</td><td>{one.writer}</td></tr>); 
         } );//map 

        return (<tbody>{tr_tag}</tbody>);

    }
}

class BoardWriteForm  extends React.Component{
    
    render(){
        // 제목, 작성자 입력 input 2개 정의
        // 글쓰기 button 1개 정의
        // 제목, 작성자 입력값 가져와서
        // 글쓰기 버튼 클릭하면 게시물번호를  현재게시물갯수+1 생성하여 alert 제목, 작성자, 번호 출력
        
        const oneboard = {seq:0, title:'', writer :''};

        const changeHandler=(event)=>{
            oneboard[event.target.id]  = event.target.value ;
        }
        const clickHandler=(event)=>{
            oneboard.seq = this.props.board.length + 1;
            alert(oneboard.seq + ":" + oneboard.title + ":" + oneboard.writer);
        }

        return(<div>
        게시물제목:<input type="text" id="title" onChange={changeHandler} />
        게시물작성자:<input type="text" id="writer" onChange={changeHandler} />
        <button  onClick={clickHandler} >글쓰기</button>
      </div>);

    }
}

class BoardList extends React.Component{
    render(){
        const board= [
            {seq:1, title:'제목1', writer : "작성자1"},
            {seq:2, title:'제목2', writer : "작성자2"},
            {seq:3, title:'제목3', writer : "작성자3"},
            {seq:4, title:'제목4', writer : "작성자4"},
            {seq:5, title:'제목5', writer : "작성자5"}
            ]
            return (<div>
                <table border="5"> 
                    <BoardHeading /> 
                    <BoardRow board = {board} />
                </table>
                <BoardWriteForm board = {board}/>
                </div>);

    }

}

export default BoardList;


